
// api.js
const express = require("express");
const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());

// Endpoint test
app.get("/", (req, res) => {
  res.json({ message: "API Dyad en ligne 🚀" });
});

// Exemple POST
app.post("/send", (req, res) => {
  res.json({ status: "ok", data: req.body });
});

app.listen(PORT, () => {
  console.log(`✅ API en cours sur le port ${PORT}`);
});
